
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'joli3',
  applicationName: 'serverless-todo-app',
  appUid: 'B3LJzWXZ47vn08fFkk',
  orgUid: '34289a95-f2b2-468b-a1db-7f864738f3af',
  deploymentUid: 'c5e9288d-a374-4159-a601-2060265f824b',
  serviceName: 'serverless-todo-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-todo-app-dev-CreateTodo', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/createTodo.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}